import express from "express";
import { createServer as createViteServer } from "vite";
import { chromium, Browser, Page } from "playwright";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '50mb' }));

  let browser: Browser | null = null;
  let page: Page | null = null;
  let context: any = null;
  const storageStatePath = path.join(process.cwd(), 'storage_state.json');
  const proxiesPath = path.join(process.cwd(), 'proxies.json');

  // Proxy Management
  let proxies: any[] = [];
  let currentProxyIndex = 0;

  const loadProxies = () => {
    try {
      if (require('fs').existsSync(proxiesPath)) {
        proxies = JSON.parse(require('fs').readFileSync(proxiesPath, 'utf8'));
      } else {
        proxies = [
          { server: 'http://192.168.1.1:8080', status: 'Active', latency: '45ms' },
          { server: 'http://45.12.34.89:3128', status: 'Active', latency: '120ms' }
        ];
        require('fs').writeFileSync(proxiesPath, JSON.stringify(proxies, null, 2));
      }
    } catch (e) {
      console.error("Error loading proxies", e);
      proxies = [];
    }
  };

  const saveProxies = () => {
    try {
      require('fs').writeFileSync(proxiesPath, JSON.stringify(proxies, null, 2));
    } catch (e) {
      console.error("Error saving proxies", e);
    }
  };

  loadProxies();

  const getNextProxy = () => {
    if (proxies.length === 0) return null;
    const proxy = proxies[currentProxyIndex];
    currentProxyIndex = (currentProxyIndex + 1) % proxies.length;
    return proxy;
  };

  const DEFAULT_FINGERPRINT = {
    userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    viewport: { width: 1280, height: 800 },
    deviceScaleFactor: 1,
    isMobile: false,
    hasTouch: false,
    locale: 'en-US',
    timezoneId: 'America/New_York',
    hardwareConcurrency: 8,
    deviceMemory: 8,
    webglVendor: 'NVIDIA Corporation',
    webglRenderer: 'NVIDIA GeForce RTX 4090'
  };

  // Behavioral Profiles
  const BEHAVIORAL_PROFILES = {
    casual: {
      jitter: 12,
      speed: 0.8,
      delayBase: 2000,
      errorRate: 0.05,
      bezierSteps: 25
    },
    power: {
      jitter: 5,
      speed: 1.5,
      delayBase: 800,
      errorRate: 0.01,
      bezierSteps: 15
    },
    bot: {
      jitter: 0,
      speed: 5.0,
      delayBase: 100,
      errorRate: 0,
      bezierSteps: 5
    }
  };

  // Human-like Interaction Logic
  const gaussianRandom = (mean: number, stdev: number) => {
    const u = 1 - Math.random();
    const v = 1 - Math.random();
    const z = Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
    return z * stdev + mean;
  };

  const getBezierPoints = (start: {x: number, y: number}, end: {x: number, y: number}, steps: number) => {
    const points = [];
    const ctrl1 = {
      x: start.x + (end.x - start.x) * Math.random(),
      y: start.y + (end.y - start.y) * Math.random()
    };
    const ctrl2 = {
      x: start.x + (end.x - start.x) * Math.random(),
      y: start.y + (end.y - start.y) * Math.random()
    };

    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      const x = Math.pow(1 - t, 3) * start.x + 3 * Math.pow(1 - t, 2) * t * ctrl1.x + 3 * (1 - t) * Math.pow(t, 2) * ctrl2.x + Math.pow(t, 3) * end.x;
      const y = Math.pow(1 - t, 3) * start.y + 3 * Math.pow(1 - t, 2) * t * ctrl1.y + 3 * (1 - t) * Math.pow(t, 2) * ctrl2.y + Math.pow(t, 3) * end.y;
      points.push({ x, y });
    }
    return points;
  };

  // API Routes
  app.get("/api/infra/proxies", (req, res) => {
    res.json({ proxies, currentProxyIndex });
  });

  app.post("/api/infra/proxies", (req, res) => {
    const { server } = req.body;
    if (server) {
      proxies.push({ server, status: 'Active', latency: 'N/A' });
      saveProxies();
    }
    res.json({ proxies });
  });

  app.delete("/api/infra/proxies", (req, res) => {
    const { index } = req.body;
    if (index !== undefined && index >= 0 && index < proxies.length) {
      proxies.splice(index, 1);
      if (currentProxyIndex >= proxies.length) currentProxyIndex = 0;
      saveProxies();
    }
    res.json({ proxies });
  });

  app.post("/api/infra/proxies/rotate", (req, res) => {
    const proxy = getNextProxy();
    res.json({ proxy, currentProxyIndex });
  });

  app.post("/api/browser/goto", async (req, res) => {
    const { url, fingerprint, sessionPersistence } = req.body;
    try {
      if (!browser) {
        const proxy = getNextProxy();
        browser = await chromium.launch({ 
          headless: true,
          proxy: proxy ? { server: proxy.server } : undefined,
          args: [
            '--no-sandbox', 
            '--disable-setuid-sandbox', 
            '--disable-blink-features=AutomationControlled',
            '--disable-infobars',
            '--window-position=0,0',
            '--ignore-certificate-errors',
            '--user-agent=' + (fingerprint?.userAgent || DEFAULT_FINGERPRINT.userAgent)
          ]
        });
      }

      // Handle Session Persistence (Storage State)
      const storageStatePath = sessionPersistence ? path.join(process.cwd(), 'session_state.json') : undefined;
      
      if (!context) {
        context = await browser.newContext({
          viewport: fingerprint?.viewport || DEFAULT_FINGERPRINT.viewport,
          userAgent: fingerprint?.userAgent || DEFAULT_FINGERPRINT.userAgent,
          deviceScaleFactor: fingerprint?.deviceScaleFactor || DEFAULT_FINGERPRINT.deviceScaleFactor,
          isMobile: fingerprint?.isMobile || DEFAULT_FINGERPRINT.isMobile,
          hasTouch: fingerprint?.hasTouch || DEFAULT_FINGERPRINT.hasTouch,
          locale: fingerprint?.locale || DEFAULT_FINGERPRINT.locale,
          timezoneId: fingerprint?.timezoneId || DEFAULT_FINGERPRINT.timezoneId,
          storageState: storageStatePath && require('fs').existsSync(storageStatePath) ? storageStatePath : undefined
        });
        
        // Advanced Anti-detection & Fingerprinting
        await context.addInitScript((fp: any) => {
          // Webdriver masking
          Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
          
          // Canvas Fingerprint Protection (Add noise)
          const originalGetImageData = CanvasRenderingContext2D.prototype.getImageData;
          CanvasRenderingContext2D.prototype.getImageData = function(x, y, w, h) {
            const imageData = originalGetImageData.apply(this, [x, y, w, h]);
            for (let i = 0; i < imageData.data.length; i += 4) {
              imageData.data[i] = imageData.data[i] + (Math.random() > 0.5 ? 1 : -1);
            }
            return imageData;
          };

          // WebGL Fingerprint Protection
          const originalGetParameter = WebGLRenderingContext.prototype.getParameter;
          WebGLRenderingContext.prototype.getParameter = function(parameter) {
            if (parameter === 37445) return fp.webglVendor || 'NVIDIA Corporation'; // UNMASKED_VENDOR_WEBGL
            if (parameter === 37446) return fp.webglRenderer || 'NVIDIA GeForce RTX 4090'; // UNMASKED_RENDERER_WEBGL
            return originalGetParameter.apply(this, [parameter]);
          };

          // Audio Fingerprint Protection
          const originalGetChannelData = AudioBuffer.prototype.getChannelData;
          AudioBuffer.prototype.getChannelData = function(channel) {
            const data = originalGetChannelData.apply(this, [channel]);
            for (let i = 0; i < data.length; i++) {
              data[i] = data[i] + (Math.random() * 0.0000001);
            }
            return data;
          };

          // Hardware Concurrency & Memory Spoofing
          Object.defineProperty(navigator, 'hardwareConcurrency', { get: () => fp.hardwareConcurrency || 8 });
          // @ts-ignore
          Object.defineProperty(navigator, 'deviceMemory', { get: () => fp.deviceMemory || 8 });

          // WebRTC Protection (Spoof local IP)
          // @ts-ignore
          const originalRTCPeerConnection = window.RTCPeerConnection;
          // @ts-ignore
          window.RTCPeerConnection = function(...args) {
            const pc = new originalRTCPeerConnection(...args);
            const originalAddIceCandidate = pc.addIceCandidate;
            pc.addIceCandidate = function(candidate: any) {
              if (candidate && candidate.candidate && candidate.candidate.includes('192.168.')) {
                return Promise.resolve();
              }
              return originalAddIceCandidate.apply(this, [candidate]);
            };
            return pc;
          };

          // Battery API Spoofing
          // @ts-ignore
          navigator.getBattery = () => Promise.resolve({
            charging: true,
            chargingTime: 0,
            dischargingTime: Infinity,
            level: 0.95,
            onchargingchange: null,
            onchargingtimechange: null,
            ondischargingtimechange: null,
            onlevelchange: null
          });

          // Media Devices Spoofing
          const originalEnumerateDevices = navigator.mediaDevices.enumerateDevices;
          navigator.mediaDevices.enumerateDevices = async () => {
            const devices = await originalEnumerateDevices.apply(navigator.mediaDevices);
            return devices.map((d, i) => ({
              deviceId: `fp-device-${i}-${Math.random().toString(36).slice(2)}`,
              kind: d.kind,
              label: d.label || `${d.kind} ${i + 1}`,
              groupId: `fp-group-${i}`
            }));
          };

          // Plugins & MimeTypes Spoofing
          // @ts-ignore
          Object.defineProperty(navigator, 'plugins', { get: () => [
            { name: 'PDF Viewer', filename: 'internal-pdf-viewer', description: 'Portable Document Format' },
            { name: 'Chrome PDF Viewer', filename: 'internal-pdf-viewer', description: 'Google Chrome PDF Viewer' },
            { name: 'Chromium PDF Viewer', filename: 'internal-pdf-viewer', description: 'Chromium PDF Viewer' },
            { name: 'Microsoft Edge PDF Viewer', filename: 'internal-pdf-viewer', description: 'Microsoft Edge PDF Viewer' },
            { name: 'WebKit built-in PDF', filename: 'internal-pdf-viewer', description: 'WebKit built-in PDF' }
          ] });
          
          // @ts-ignore
          Object.defineProperty(navigator, 'languages', { get: () => [fp.locale || 'en-US', 'en'] });

          // Window dimensions alignment
          // @ts-ignore
          window.outerWidth = window.innerWidth;
          // @ts-ignore
          window.outerHeight = window.innerHeight;

          // @ts-ignore
          window.chrome = { runtime: {} };
        }, fingerprint || DEFAULT_FINGERPRINT);

        page = await context.newPage();
      }
      
      // Network Throttling Simulation (if requested)
      if (req.body.networkThrottling) {
        const { latency, downloadThroughput, uploadThroughput, packetLoss, jitter } = req.body.networkThrottling;
        const cdpSession = await page!.context().newCDPSession(page!);
        
        // Base throttling
        await cdpSession.send('Network.emulateNetworkConditions', {
          offline: false,
          latency: (latency || 0) + (jitter ? gaussianRandom(0, jitter) : 0),
          downloadThroughput: (downloadThroughput || -1) * 1024 / 8,
          uploadThroughput: (uploadThroughput || -1) * 1024 / 8,
        });

        // Advanced: Packet loss simulation (via CDP if available, or just extra latency)
        // Note: Real packet loss is hard in CDP, we simulate it with high latency spikes
        if (packetLoss && Math.random() < (packetLoss / 100)) {
          await page!.waitForTimeout(gaussianRandom(2000, 500));
        }
      }

      await page!.goto(url, { waitUntil: 'networkidle' });
      
      // Save session state if persistence is enabled
      if (sessionPersistence) {
        await context.storageState({ path: storageStatePath });
      }

      const screenshot = await page!.screenshot({ type: 'png' });
      
      res.json({ 
        screenshot: `data:image/png;base64,${screenshot.toString('base64')}`,
        url: page!.url(),
        fingerprint: fingerprint || DEFAULT_FINGERPRINT
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/browser/action", async (req, res) => {
    const { type, x, y, text, targetX, targetY, realism, profile } = req.body;
    try {
      if (!page) throw new Error("No page active");

      const viewport = page.viewportSize() || { width: 1280, height: 800 };
      const fast = req.body.fast;

      // Behavioral Profile Selection
      const selectedProfile = BEHAVIORAL_PROFILES[profile as keyof typeof BEHAVIORAL_PROFILES] || BEHAVIORAL_PROFILES.power;
      
      // Human-like Interaction Logic
      const jitter = realism?.jitter || selectedProfile.jitter;
      const addJitter = (val: number) => val + gaussianRandom(0, jitter);

      if (type === 'click') {
        const px = addJitter(x * viewport.width);
        const py = addJitter(y * viewport.height);
        
        // Bezier movement
        const currentPos = { x: viewport.width / 2, y: viewport.height / 2 }; 
        const points = getBezierPoints(currentPos, { x: px, y: py }, fast ? 5 : selectedProfile.bezierSteps);
        for (const pt of points) {
          await page.mouse.move(pt.x, pt.y);
          await page.waitForTimeout(gaussianRandom(10 / selectedProfile.speed, 5));
        }

        // Random hesitation
        if (Math.random() < selectedProfile.errorRate) {
          await page.waitForTimeout(gaussianRandom(500, 200));
        }

        await page.waitForTimeout(gaussianRandom(200 / selectedProfile.speed, 50)); 
        await page.mouse.click(px, py, { delay: gaussianRandom(100 / selectedProfile.speed, 20) });
      } else if (type === 'type') {
        const px = addJitter(x * viewport.width);
        const py = addJitter(y * viewport.height);
        
        await page.mouse.move(px, py, { steps: fast ? 5 : selectedProfile.bezierSteps });
        await page.mouse.click(px, py);
        await page.waitForTimeout(gaussianRandom(400 / selectedProfile.speed, 100)); 
        
        // Human-like typing
        if (realism?.humanTyping) {
          for (const char of (text || "")) {
            // Occasional typo simulation
            if (Math.random() < selectedProfile.errorRate) {
              const wrongChar = String.fromCharCode(char.charCodeAt(0) + 1);
              await page.keyboard.type(wrongChar, { delay: gaussianRandom(100, 30) });
              await page.waitForTimeout(gaussianRandom(300, 100));
              await page.keyboard.press('Backspace', { delay: gaussianRandom(100, 30) });
            }

            await page.keyboard.type(char, { delay: gaussianRandom(120 / selectedProfile.speed, 40) });
            if (Math.random() > 0.95) await page.waitForTimeout(gaussianRandom(600 / selectedProfile.speed, 200)); 
          }
        } else {
          await page.keyboard.type(text || "");
        }
      } else if (type === 'drag') {
        const sx = addJitter(x * viewport.width);
        const sy = addJitter(y * viewport.height);
        const tx = addJitter(targetX * viewport.width);
        const ty = addJitter(targetY * viewport.height);
        
        await page.mouse.move(sx, sy, { steps: fast ? 5 : selectedProfile.bezierSteps });
        await page.mouse.down();
        await page.waitForTimeout(gaussianRandom(100 / selectedProfile.speed, 30));
        
        const points = getBezierPoints({x: sx, y: sy}, {x: tx, y: ty}, fast ? 10 : selectedProfile.bezierSteps * 1.5);
        for (const pt of points) {
          await page.mouse.move(pt.x, pt.y);
          await page.waitForTimeout(gaussianRandom(15 / selectedProfile.speed, 5));
        }

        await page.waitForTimeout(gaussianRandom(100 / selectedProfile.speed, 30));
        await page.mouse.up();
      } else if (type === 'refresh') {
        await page.reload({ waitUntil: 'networkidle' });
      }

      // Random post-action delay
      if (realism?.randomDelays) {
        await page.waitForTimeout(gaussianRandom(selectedProfile.delayBase, 500));
      } else {
        await page.waitForTimeout(1000);
      }

      // Save storage state for persistence if enabled
      if (req.body.sessionPersistence && storageStatePath) {
        await page.context().storageState({ path: storageStatePath });
      }

      const screenshot = await page.screenshot({ type: 'png' });
      
      res.json({ 
        screenshot: `data:image/png;base64,${screenshot.toString('base64')}`,
        url: page.url()
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

    // Get Session State (Cookies + LocalStorage + UserAgent)
    app.get('/api/browser/state', async (req, res) => {
      if (!page) return res.status(400).json({ error: 'No active session' });
      try {
        const cookies = await page.context().cookies();
        const localStorage = await page.evaluate(() => JSON.stringify(window.localStorage));
        const userAgent = await page.evaluate(() => navigator.userAgent);
        res.json({ 
          cookies, 
          localStorage: JSON.parse(localStorage),
          userAgent,
          url: page.url()
        });
      } catch (error: any) {
        res.status(500).json({ error: error.message });
      }
    });

    // Execute Script
    app.post('/api/browser/execute', async (req, res) => {
      const { script } = req.body;
      if (!page) return res.status(400).json({ error: 'No active session' });
      try {
        const result = await page.evaluate(script);
        const screenshot = await page.screenshot({ type: 'png' });
        res.json({ 
          result, 
          screenshot: `data:image/png;base64,${screenshot.toString('base64')}` 
        });
      } catch (error: any) {
        res.status(500).json({ error: error.message });
      }
    });

    app.get("/api/browser/screenshot", async (req, res) => {
    try {
      if (!page) throw new Error("No page active");
      const screenshot = await page.screenshot({ type: 'png' });
      res.json({ screenshot: `data:image/png;base64,${screenshot.toString('base64')}` });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
