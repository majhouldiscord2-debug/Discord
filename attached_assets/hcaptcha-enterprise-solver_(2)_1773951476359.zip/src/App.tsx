import React, { useState, useRef, useCallback, useEffect } from 'react';
import { 
  Shield, 
  Upload, 
  Grid, 
  CheckCircle2, 
  AlertCircle, 
  Loader2, 
  RefreshCw,
  Search,
  Cpu,
  Move,
  FileText,
  Menu,
  ChevronDown,
  LayoutDashboard,
  Globe,
  Database,
  Users,
  Copy,
  Info,
  ExternalLink,
  Clock,
  Activity,
  Server,
  ChevronRight,
  Inbox,
  Fingerprint,
  Zap,
  Wifi,
  History,
  MousePointer2,
  Download
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { solveCaptcha, detectPrompt, CaptchaResult } from './services/gemini';

export default function App() {
  const [activeTab, setActiveTab] = useState<'solver' | 'browser' | 'infra' | 'human' | 'realism' | 'mission'>('mission');
  const [menuOpen, setMenuOpen] = useState(false);
  const [prompt, setPrompt] = useState('Select all images with a bus');
  const [images, setImages] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<CaptchaResult | null>(null);
  const [browserUrl, setBrowserUrl] = useState('https://www.google.com/recaptcha/api2/demo');
  const [browserScreenshot, setBrowserScreenshot] = useState<string | null>(null);
  const [browserLoading, setBrowserLoading] = useState(false);
  const [behavioralProfile, setBehavioralProfile] = useState<'casual' | 'power' | 'bot'>('power');
  const [logs, setLogs] = useState<{ id: string; msg: string; type: 'info' | 'warn' | 'error'; time: string }[]>([]);

  const addLog = (msg: string, type: 'info' | 'warn' | 'error' = 'info') => {
    setLogs(prev => [{
      id: Math.random().toString(36).slice(2, 9),
      msg,
      type,
      time: new Date().toLocaleTimeString()
    }, ...prev.slice(0, 49)]);
  };
  const [pendingAction, setPendingAction] = useState<{
    type: 'click' | 'drag' | 'type';
    x: number;
    y: number;
    targetX?: number;
    targetY?: number;
    text?: string;
    reasoning: string;
  } | null>(null);

  // Realism & Network State
  const [realismSettings, setRealismSettings] = useState({
    jitter: 5,
    humanTyping: true,
    randomDelays: true,
    sessionPersistence: true,
    canvasProtection: true,
    webglProtection: true,
    audioProtection: true,
  });

  const [reputation, setReputation] = useState({
    trustScore: 85,
    ipQuality: 'High',
    sessionAge: '14 days',
    history: [
      { event: 'Session Created', status: 'Success', time: '2026-03-19 10:00' },
      { event: 'Challenge Solved', status: 'Success', time: '2026-03-19 10:15' },
      { event: 'Navigation', status: 'Success', time: '2026-03-19 10:30' },
    ]
  });

  const [networkThrottling, setNetworkThrottling] = useState({
    latency: 50,
    downloadThroughput: 10000,
    uploadThroughput: 5000,
    packetLoss: 0,
    jitter: 10
  });

  const handleBrowserGoto = async () => {
    setBrowserLoading(true);
    setError(null);
    addLog(`Navigating to ${browserUrl}...`, 'info');
    try {
      const response = await fetch('/api/browser/goto', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          url: browserUrl,
          fingerprint,
          sessionPersistence: realismSettings.sessionPersistence,
          networkThrottling
        })
      });
      const data = await response.json();
      if (data.error) {
        setError(`Navigation failed: ${data.error}`);
        addLog(`Navigation failed: ${data.error}`, 'error');
      } else if (data.screenshot) {
        setBrowserScreenshot(data.screenshot);
        setImages([data.screenshot]);
        addLog(`Successfully loaded ${data.url}`, 'info');
      }
    } catch (error: any) {
      setError(`Browser error: ${error.message}`);
      addLog(`Browser error: ${error.message}`, 'error');
      console.error("Browser error:", error);
    } finally {
      setBrowserLoading(false);
    }
  };

  const handleBrowserAction = async (type: string, x: number, y: number, text?: string, targetX?: number, targetY?: number) => {
    setBrowserLoading(true);
    setError(null);
    addLog(`Executing ${type} at (${x.toFixed(2)}, ${y.toFixed(2)})...`, 'info');
    try {
      const response = await fetch('/api/browser/action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          type, x, y, text, targetX, targetY, 
          fast: turboMode,
          realism: realismSettings,
          profile: behavioralProfile
        })
      });
      const data = await response.json();
      if (data.error) {
        setError(`Action failed: ${data.error}`);
        addLog(`Action failed: ${data.error}`, 'error');
      } else if (data.screenshot) {
        setBrowserScreenshot(data.screenshot);
        setImages([data.screenshot]);
        
        // Trust Accumulation
        setReputation(prev => ({
          ...prev,
          trustScore: Math.min(100, prev.trustScore + 1),
          history: [
            { event: `${type.toUpperCase()} Action`, status: 'Success', time: new Date().toISOString().replace('T', ' ').slice(0, 16) },
            ...prev.history.slice(0, 4)
          ]
        }));
        addLog(`${type.toUpperCase()} action completed successfully`, 'info');
      }
    } catch (error: any) {
      setError(`Action error: ${error.message}`);
      addLog(`Action error: ${error.message}`, 'error');
      console.error("Browser action error:", error);
    } finally {
      setBrowserLoading(false);
    }
  };

  const handleSolveOnPage = async () => {
    if (!browserScreenshot) return;
    setLoading(true);
    setPendingAction(null);
    try {
      // 1. Detect prompt from page
      const detected = await detectPrompt([browserScreenshot], turboMode);
      setPrompt(detected || "Analyze the page for challenges");
      
      // 2. Solve challenge
      const solvePrompt = detected 
        ? `Solve this challenge: ${detected}`
        : "Identify any interactive elements like 'I'm not a robot' checkboxes, login buttons, text input fields, or slider puzzles on this page and provide coordinates to interact with them.";
      
      const res = await solveCaptcha(solvePrompt, [browserScreenshot], turboMode);
      setResult(res);

      // 3. Set pending action instead of immediate execution
      if (res.puzzleData) {
        const { sourceX, sourceY, targetX, targetY, text, reasoning } = res.puzzleData;
        
        let action: any = null;
        if (text) {
          action = { type: 'type', x: targetX, y: targetY, text, reasoning };
        } else if (sourceX !== undefined && sourceY !== undefined) {
          action = { type: 'drag', x: sourceX, y: sourceY, targetX, targetY, reasoning };
        } else {
          action = { type: 'click', x: targetX, y: targetY, reasoning };
        }

        if (action) {
          if (fullAuto) {
            // Execute immediately in full auto mode
            await handleBrowserAction(action.type, action.x, action.y, action.text, action.targetX, action.targetY);
          } else {
            setPendingAction(action);
          }
        }
      }
    } catch (error: any) {
      const errorMessage = error.message || String(error);
      if (errorMessage.includes('API_KEY_INVALID')) {
        setError("Invalid Gemini API Key. Please check your environment variables or settings.");
      } else if (errorMessage.includes('quota')) {
        setError("API Quota exceeded. Please try again later or check your billing status.");
      } else if (errorMessage.includes('network') || errorMessage.includes('fetch')) {
        setError("Network error: Unable to connect to the AI service. Please check your internet connection.");
      } else {
        setError(`Solve error: ${errorMessage}`);
      }
      console.error("Solve error:", error);
    } finally {
      setLoading(false);
    }
  };

  const executePendingAction = useCallback(async () => {
    if (!pendingAction) return;
    const { type, x, y, text, targetX, targetY } = pendingAction;
    await handleBrowserAction(type, x, y, text, targetX, targetY);
    setPendingAction(null);
    setResult(null);
  }, [pendingAction, handleBrowserAction]);
  const [error, setError] = useState<string | null>(null);
  const [detecting, setDetecting] = useState(false);
  const [fullAuto, setFullAuto] = useState(false);
  const [turboMode, setTurboMode] = useState(false);
  const [stealthMode, setStealthMode] = useState(true);
  const [solvingProgress, setSolvingProgress] = useState(0);
  const [copied, setCopied] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Browser Profile State
  const [fingerprint, setFingerprint] = useState({
    userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
    resolution: '1920x1080',
    webglVendor: 'NVIDIA Corporation',
    webglRenderer: 'NVIDIA GeForce RTX 4090',
    language: 'en-US',
    timezone: 'America/New_York',
    hardwareConcurrency: 8,
    deviceMemory: 8
  });

  // Infra State
  const [proxies, setProxies] = useState<{ server: string; status: string; latency: string }[]>([]);
  const [currentProxyIndex, setCurrentProxyIndex] = useState(0);

  const fetchProxies = async () => {
    try {
      const res = await fetch('/api/infra/proxies');
      const data = await res.json();
      setProxies(data.proxies);
      setCurrentProxyIndex(data.currentProxyIndex);
    } catch (e) {
      console.error("Failed to fetch proxies", e);
    }
  };

  useEffect(() => {
    fetchProxies();
  }, []);

  const handleRotateProxy = async () => {
    addLog("Rotating proxy...", 'info');
    try {
      const res = await fetch('/api/infra/proxies/rotate', { method: 'POST' });
      const data = await res.json();
      setCurrentProxyIndex(data.currentProxyIndex);
      addLog(`Proxy rotated to ${data.proxy?.server || 'None'}`, 'info');
      setReputation(prev => ({
        ...prev,
        history: [
          { event: 'Proxy Rotated', status: 'Success', time: new Date().toISOString().replace('T', ' ').slice(0, 16) },
          ...prev.history.slice(0, 4)
        ]
      }));
    } catch (e) {
      addLog("Proxy rotation failed", 'error');
      console.error("Rotation failed", e);
    }
  };

  const handleAddProxy = async () => {
    const server = prompt("Enter proxy server (e.g., http://user:pass@host:port):");
    if (!server) return;
    try {
      const res = await fetch('/api/infra/proxies', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ server })
      });
      const data = await res.json();
      setProxies(data.proxies);
    } catch (e) {
      console.error("Add proxy failed", e);
    }
  };

  const handleDeleteProxy = async (index: number) => {
    if (!confirm("Delete this proxy?")) return;
    try {
      const res = await fetch('/api/infra/proxies', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ index })
      });
      const data = await res.json();
      setProxies(data.proxies);
    } catch (e) {
      console.error("Delete proxy failed", e);
    }
  };

  // Human-in-the-loop State
  const [humanQueue, setHumanQueue] = useState([
    { id: 'CH-8821', timestamp: '15:21:02', status: 'Pending', type: 'hCaptcha Enterprise' },
    { id: 'CH-8819', timestamp: '15:19:45', status: 'Solved', type: 'hCaptcha Enterprise' },
  ]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    const newImages: string[] = [];
    Array.from(files).forEach((file: File) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        newImages.push(reader.result as string);
        if (newImages.length === files.length) {
          const updatedImages = [...images, ...newImages].slice(0, 10); // Allow 10 to include header
          setImages(updatedImages);
          
          // Auto-detect prompt if empty or if a new batch is added
          if (updatedImages.length > 0) {
            handleDetectPrompt(updatedImages);
          }
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const handleDetectPrompt = useCallback(async (imgs: string[] = images) => {
    if (imgs.length === 0) return;
    setDetecting(true);
    try {
      const detected = await detectPrompt(imgs);
      if (detected) {
        setPrompt(detected);
        if (fullAuto) {
          // Small delay to ensure state updates
          setTimeout(() => handleSolve(detected, imgs), turboMode ? 100 : 500);
        }
      }
    } catch (err) {
      console.error("Prompt detection failed", err);
    } finally {
      setDetecting(false);
    }
  }, [images, fullAuto, turboMode]);

  const handleSolve = useCallback(async (overridePrompt?: string, overrideImages?: string[]) => {
    const currentPrompt = overridePrompt || prompt;
    const currentImages = overrideImages || images;

    if (currentImages.length === 0) {
      setError("Please upload some images first.");
      return;
    }
    setLoading(true);
    setError(null);
    setResult(null);

    try {
      // Human Latency Simulation
      if (stealthMode && !turboMode) {
        setSolvingProgress(10);
        await new Promise(r => setTimeout(r, 800 + Math.random() * 1200));
        setSolvingProgress(40);
        await new Promise(r => setTimeout(r, 500 + Math.random() * 1000));
        setSolvingProgress(70);
      }

      const res = await solveCaptcha(currentPrompt, currentImages, turboMode);
      
      if (stealthMode && !turboMode) {
        setSolvingProgress(90);
        await new Promise(r => setTimeout(r, 400 + Math.random() * 600));
        setSolvingProgress(100);
      }

      setResult(res);
    } catch (err: any) {
      const errorMessage = err.message || String(err);
      if (errorMessage.includes('API_KEY_INVALID')) {
        setError("Invalid Gemini API Key. Please check your environment variables or settings.");
      } else if (errorMessage.includes('quota')) {
        setError("API Quota exceeded. Please try again later or check your billing status.");
      } else if (errorMessage.includes('network') || errorMessage.includes('fetch')) {
        setError("Network error: Unable to connect to the AI service. Please check your internet connection.");
      } else {
        setError(`Failed to solve verification: ${errorMessage}`);
      }
      console.error("Solve error:", err);
    } finally {
      setLoading(false);
      setSolvingProgress(0);
    }
  }, [prompt, images, stealthMode, turboMode]);

  const reset = useCallback(() => {
    setImages([]);
    setResult(null);
    setError(null);
  }, []);

  // Keyboard Shortcuts & Paste Support
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't trigger if user is typing in an input or textarea
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
        return;
      }

      // Escape to cancel pending action or reset errors
      if (e.key === 'Escape') {
        if (pendingAction) {
          setPendingAction(null);
        } else {
          setError(null);
        }
        return;
      }

      // Ctrl+Enter to confirm pending action
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
        if (pendingAction) {
          e.preventDefault();
          executePendingAction();
        }
        return;
      }

      if (e.ctrlKey || e.metaKey) {
        const key = e.key.toLowerCase();
        if (key === 's') {
          e.preventDefault();
          handleSolve();
        } else if (key === 'r') {
          e.preventDefault();
          reset();
        }
      }
    };

    const handlePaste = (e: ClipboardEvent) => {
      const items = e.clipboardData?.items;
      if (!items) return;

      const imageItems = Array.from(items).filter(item => item.type.startsWith('image/'));
      if (imageItems.length === 0) return;

      const newImages: string[] = [];
      imageItems.forEach(item => {
        const file = item.getAsFile();
        if (file) {
          const reader = new FileReader();
          reader.onloadend = () => {
            newImages.push(reader.result as string);
            if (newImages.length === imageItems.length) {
              setImages(prev => {
                const updated = [...prev, ...newImages].slice(0, 10);
                handleDetectPrompt(updated);
                return updated;
              });
            }
          };
          reader.readAsDataURL(file);
        }
      });
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('paste', handlePaste);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('paste', handlePaste);
    };
  }, [handleSolve, reset, handleDetectPrompt, executePendingAction, pendingAction]);

  return (
    <div className="min-h-screen bg-bg text-ink font-sans selection:bg-ink selection:text-bg">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-bg/80 backdrop-blur-md border-b border-ink/10 p-4 sm:px-8">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-4">
            <div className="bg-ink text-bg p-2 rounded-lg shadow-lg">
              <Shield className="w-6 h-6" />
            </div>
            <div className="flex flex-col">
              <h1 className="text-lg font-black tracking-tighter uppercase leading-none">
                Bot <span className="text-accent italic font-serif lowercase font-normal">verify</span>
              </h1>
              <span className="text-[8px] font-mono uppercase tracking-[0.3em] opacity-40">Mission Control v2.4</span>
            </div>
          </div>

          <nav className="hidden md:flex items-center gap-1 bg-ink/5 p-1 rounded-xl tech-border">
            {[
              { id: 'mission', label: 'Mission Control', icon: LayoutDashboard },
              { id: 'solver', label: 'AI Solver', icon: Cpu },
              { id: 'browser', label: 'Browser', icon: Globe },
              { id: 'infra', label: 'Infrastructure', icon: Database },
              { id: 'realism', label: 'Realism Engine', icon: Fingerprint },
              { id: 'human', label: 'Human-In-Loop', icon: Users },
            ].map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id as any)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-[10px] font-mono uppercase tracking-widest transition-all ${
                  activeTab === item.id 
                    ? 'bg-ink text-bg shadow-lg' 
                    : 'hover:bg-ink/5 opacity-60 hover:opacity-100'
                }`}
              >
                <item.icon className="w-3 h-3" />
                {item.label}
              </button>
            ))}
          </nav>

          <div className="flex items-center gap-4">
            <div className="hidden sm:flex flex-col items-end">
              <div className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 bg-accent rounded-full animate-pulse glow-emerald" />
                <span className="text-[9px] font-mono uppercase tracking-widest font-bold">System Online</span>
              </div>
              <span className="text-[8px] font-mono opacity-30">LATENCY: 42ms</span>
            </div>
            
            <button 
              onClick={() => setMenuOpen(!menuOpen)}
              className="md:hidden p-2 hover:bg-ink/5 rounded-lg transition-colors"
            >
              <Menu className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto p-4 sm:p-8 space-y-8">
        {/* Content Area */}
        <div className="w-full">
          {activeTab === 'mission' && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-8"
            >
              {/* System Overview Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="tech-card p-6 rounded-2xl space-y-4">
                  <div className="flex justify-between items-start">
                    <div className="p-2 bg-accent/10 rounded-lg text-accent">
                      <Shield className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-mono opacity-40 uppercase tracking-widest">Trust Score</span>
                  </div>
                  <div className="space-y-1">
                    <div className="text-3xl font-black tracking-tighter">{reputation.trustScore}%</div>
                    <div className="h-1 bg-ink/5 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${reputation.trustScore}%` }}
                        className="h-full bg-accent"
                      />
                    </div>
                  </div>
                </div>

                <div className="tech-card p-6 rounded-2xl space-y-4">
                  <div className="flex justify-between items-start">
                    <div className="p-2 bg-blue-500/10 rounded-lg text-blue-500">
                      <Globe className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-mono opacity-40 uppercase tracking-widest">Active Proxy</span>
                  </div>
                  <div className="space-y-1">
                    <div className="text-sm font-bold truncate">
                      {proxies[currentProxyIndex]?.server || 'Direct Connection'}
                    </div>
                    <div className="text-[10px] font-mono text-emerald-500 uppercase font-bold">Latency: {proxies[currentProxyIndex]?.latency || '42ms'}</div>
                  </div>
                </div>

                <div className="tech-card p-6 rounded-2xl space-y-4">
                  <div className="flex justify-between items-start">
                    <div className="p-2 bg-amber-500/10 rounded-lg text-amber-500">
                      <Fingerprint className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-mono opacity-40 uppercase tracking-widest">Behavioral Profile</span>
                  </div>
                  <div className="space-y-1">
                    <div className="text-xl font-black uppercase tracking-tight">{behavioralProfile}</div>
                    <div className="text-[10px] font-mono opacity-40 uppercase">Jitter: {realismSettings.jitter}px</div>
                  </div>
                </div>

                <div className="tech-card p-6 rounded-2xl space-y-4">
                  <div className="flex justify-between items-start">
                    <div className="p-2 bg-purple-500/10 rounded-lg text-purple-500">
                      <Clock className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-mono opacity-40 uppercase tracking-widest">Session Age</span>
                  </div>
                  <div className="space-y-1">
                    <div className="text-xl font-black">{reputation.sessionAge}</div>
                    <div className="text-[10px] font-mono opacity-40 uppercase">Status: Warm</div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                {/* Live Operation Log */}
                <section className="lg:col-span-8 space-y-4">
                  <div className="flex justify-between items-center">
                    <h3 className="tech-label">Live Operation Log</h3>
                    <button 
                      onClick={() => setLogs([])}
                      className="text-[10px] font-mono uppercase tracking-widest opacity-40 hover:opacity-100 transition-opacity"
                    >
                      Clear Logs
                    </button>
                  </div>
                  <div className="tech-card rounded-2xl h-[400px] overflow-hidden flex flex-col">
                    <div className="flex-1 overflow-y-auto p-4 space-y-2 font-mono text-[11px]">
                      {logs.length > 0 ? logs.map((log) => (
                        <div key={log.id} className="flex gap-4 group">
                          <span className="opacity-20 shrink-0">[{log.time}]</span>
                          <span className={`${
                            log.type === 'error' ? 'text-red-500' :
                            log.type === 'warn' ? 'text-amber-500' :
                            'text-ink/60'
                          }`}>
                            {log.msg}
                          </span>
                        </div>
                      )) : (
                        <div className="h-full flex flex-col items-center justify-center opacity-20 gap-4">
                          <Activity className="w-8 h-8 animate-pulse" />
                          <p className="uppercase tracking-[0.2em]">Awaiting Operations...</p>
                        </div>
                      )}
                    </div>
                    <div className="p-3 bg-ink/5 border-t border-ink/5 flex justify-between items-center">
                      <div className="flex gap-4">
                        <div className="flex items-center gap-2">
                          <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full" />
                          <span className="text-[9px] font-mono uppercase opacity-40">Engine: Ready</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full" />
                          <span className="text-[9px] font-mono uppercase opacity-40">Network: Stable</span>
                        </div>
                      </div>
                      <span className="text-[9px] font-mono uppercase opacity-20">Buffer: {logs.length}/50</span>
                    </div>
                  </div>
                </section>

                {/* Quick Actions & Health */}
                <section className="lg:col-span-4 space-y-8">
                  <div className="tech-card p-6 rounded-2xl space-y-6">
                    <h3 className="tech-label">Quick Actions</h3>
                    <div className="grid grid-cols-1 gap-3">
                      <button 
                        onClick={handleBrowserGoto}
                        className="flex items-center justify-between p-4 rounded-xl border border-ink/10 hover:bg-ink/5 transition-all group"
                      >
                        <div className="flex items-center gap-3">
                          <RefreshCw className="w-4 h-4 opacity-40 group-hover:rotate-180 transition-transform duration-500" />
                          <span className="text-xs font-bold uppercase tracking-tight">Re-initialize Session</span>
                        </div>
                        <ChevronRight className="w-3 h-3 opacity-20" />
                      </button>
                      <button 
                        onClick={handleRotateProxy}
                        className="flex items-center justify-between p-4 rounded-xl border border-ink/10 hover:bg-ink/5 transition-all group"
                      >
                        <div className="flex items-center gap-3">
                          <Server className="w-4 h-4 opacity-40" />
                          <span className="text-xs font-bold uppercase tracking-tight">Rotate Network Node</span>
                        </div>
                        <ChevronRight className="w-3 h-3 opacity-20" />
                      </button>
                      <button 
                        onClick={() => setActiveTab('realism')}
                        className="flex items-center justify-between p-4 rounded-xl border border-ink/10 hover:bg-ink/5 transition-all group"
                      >
                        <div className="flex items-center gap-3">
                          <Fingerprint className="w-4 h-4 opacity-40" />
                          <span className="text-xs font-bold uppercase tracking-tight">Adjust Realism Profile</span>
                        </div>
                        <ChevronRight className="w-3 h-3 opacity-20" />
                      </button>
                    </div>
                  </div>

                  <div className="tech-card p-6 rounded-2xl space-y-6">
                    <h3 className="tech-label">System Health</h3>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <div className="flex justify-between text-[10px] font-mono uppercase opacity-40">
                          <span>CPU Load</span>
                          <span>12%</span>
                        </div>
                        <div className="h-1 bg-ink/5 rounded-full overflow-hidden">
                          <div className="h-full bg-emerald-500 w-[12%]" />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between text-[10px] font-mono uppercase opacity-40">
                          <span>Memory Usage</span>
                          <span>1.2GB / 8GB</span>
                        </div>
                        <div className="h-1 bg-ink/5 rounded-full overflow-hidden">
                          <div className="h-full bg-emerald-500 w-[15%]" />
                        </div>
                      </div>
                    </div>
                  </div>
                </section>
              </div>
            </motion.div>
          )}

          {activeTab === 'solver' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              {/* Left Column: Input & Controls */}
              <section className="lg:col-span-5 space-y-8">
                <div className="tech-card p-6 rounded-2xl space-y-6">
                  <div className="flex items-center justify-between">
                    <h3 className="tech-label">01. Configuration</h3>
                    <div className="flex gap-2">
                      <button 
                        onClick={() => {
                          setTurboMode(!turboMode);
                          if (!turboMode) setFullAuto(true);
                        }}
                        title="Turbo Mode: Maximum speed analysis"
                        className={`p-2 rounded-lg transition-all border ${turboMode ? 'bg-red-500 border-red-600 text-white glow-amber' : 'tech-border opacity-40'}`}
                      >
                        <RefreshCw className={`w-4 h-4 ${turboMode ? 'animate-spin' : ''}`} />
                      </button>
                      <button 
                        onClick={() => setFullAuto(!fullAuto)}
                        title="Full Auto: Automated execution"
                        className={`p-2 rounded-lg transition-all border ${fullAuto ? 'bg-accent border-accent/20 text-white glow-emerald' : 'tech-border opacity-40'}`}
                      >
                        <CheckCircle2 className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => setStealthMode(!stealthMode)}
                        title="Stealth Mode: Human simulation"
                        className={`p-2 rounded-lg transition-all border ${stealthMode ? 'bg-warning border-warning/20 text-white glow-amber' : 'tech-border opacity-40'}`}
                      >
                        <Shield className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="relative group">
                      <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 opacity-30 group-focus-within:opacity-100 transition-opacity" />
                      <input 
                        type="text" 
                        value={prompt}
                        onChange={(e) => setPrompt(e.target.value)}
                        placeholder="Detection prompt..."
                        className="w-full bg-ink/5 border border-ink/10 rounded-xl p-4 pl-12 focus:outline-none focus:ring-2 focus:ring-ink/5 transition-all font-mono text-xs"
                      />
                    </div>
                    
                    <div 
                      onClick={() => fileInputRef.current?.click()}
                      className="border-2 border-dashed border-ink/10 rounded-2xl p-8 flex flex-col items-center justify-center gap-3 cursor-pointer hover:bg-ink/5 hover:border-ink/20 transition-all group"
                    >
                      <div className="bg-ink/5 p-4 rounded-full group-hover:scale-110 transition-transform">
                        <Upload className="w-6 h-6 opacity-40" />
                      </div>
                      <div className="text-center">
                        <p className="text-[10px] font-mono uppercase tracking-widest font-bold">Drop grid assets</p>
                        <p className="text-[8px] font-mono opacity-30 uppercase tracking-[0.2em] mt-1">PNG, JPG, WEBP (MAX 9)</p>
                      </div>
                      <input 
                        type="file" 
                        multiple 
                        accept="image/*" 
                        ref={fileInputRef}
                        onChange={handleFileUpload}
                        className="hidden"
                      />
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <button 
                      onClick={() => handleSolve()}
                      disabled={loading || images.length === 0 || !prompt}
                      className="flex-1 bg-ink text-bg p-4 rounded-xl font-mono text-[10px] uppercase tracking-[0.2em] hover:bg-ink/90 hover:scale-[1.02] active:scale-[0.98] transition-all disabled:opacity-30 disabled:cursor-not-allowed flex items-center justify-center gap-3 shadow-xl"
                    >
                      {loading ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <Cpu className="w-4 h-4" />
                      )}
                      {loading ? 'Processing...' : 'Solve Challenge'}
                    </button>
                    <button 
                      onClick={reset}
                      className="tech-border p-4 rounded-xl hover:bg-ink/5 transition-all"
                      title="Reset"
                    >
                      <RefreshCw className="w-4 h-4 opacity-40" />
                    </button>
                  </div>
                </div>

                {error && (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="p-6 bg-red-50 border border-red-200 text-red-900 rounded-2xl space-y-4 shadow-xl"
                  >
                    <div className="flex items-center gap-3">
                      <AlertCircle className="w-5 h-5 text-red-600" />
                      <h3 className="font-bold uppercase tracking-wider text-[10px] font-mono">System Error</h3>
                    </div>
                    <p className="text-[10px] font-mono bg-red-100/50 p-3 rounded-lg border border-red-200/50">{error}</p>
                    <button 
                      onClick={() => setError(null)}
                      className="w-full py-2 bg-red-600 text-white text-[9px] font-mono uppercase tracking-widest rounded-lg hover:bg-red-700 transition-all"
                    >
                      Dismiss
                    </button>
                  </motion.div>
                )}

                <div className="tech-card p-6 rounded-2xl space-y-4">
                  <h3 className="tech-label">02. Execution Pipeline</h3>
                  <div className="space-y-4">
                    {[
                      { id: 1, label: 'Visual Analysis', status: loading ? 'active' : (result ? 'complete' : 'pending') },
                      { id: 2, label: 'Coordinate Mapping', status: loading ? 'pending' : (result ? 'complete' : 'pending') },
                      { id: 3, label: 'Bypass Execution', status: result ? 'active' : 'pending' }
                    ].map((step) => (
                      <div key={step.id} className="flex items-center gap-4">
                        <div className={`w-6 h-6 rounded-lg border flex items-center justify-center font-mono text-[10px] transition-all ${
                          step.status === 'complete' ? 'bg-accent border-accent text-white' :
                          step.status === 'active' ? 'border-ink bg-ink text-bg animate-pulse' :
                          'border-ink/10 opacity-20'
                        }`}>
                          {step.status === 'complete' ? <CheckCircle2 className="w-3 h-3" /> : step.id}
                        </div>
                        <span className={`text-[10px] font-mono uppercase tracking-widest ${step.status === 'pending' ? 'opacity-20' : 'font-bold'}`}>
                          {step.label}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </section>

              {/* Right Column: Preview & Results */}
              <section className="lg:col-span-7 space-y-8">
                <div className="tech-card p-1 rounded-2xl overflow-hidden bg-white shadow-2xl">
                  <div className="bg-ink/5 p-3 flex items-center justify-between border-b border-ink/5">
                    <h3 className="tech-label">03. Visual Preview</h3>
                    <div className="flex gap-1">
                      <div className="w-1.5 h-1.5 rounded-full bg-red-400/50" />
                      <div className="w-1.5 h-1.5 rounded-full bg-amber-400/50" />
                      <div className="w-1.5 h-1.5 rounded-full bg-accent/50" />
                    </div>
                  </div>
                  <div className="aspect-video bg-stone-50 relative group">
                    {loading && (
                      <div className="absolute inset-0 z-30 bg-bg/80 backdrop-blur-md flex flex-col items-center justify-center gap-4">
                        <div className="relative">
                          <Loader2 className="w-12 h-12 animate-spin text-ink" />
                          <div className="absolute inset-0 animate-ping rounded-full border-2 border-ink/10" />
                        </div>
                        <div className="text-center">
                          <p className="text-[10px] font-mono uppercase tracking-widest font-bold">AI Neural Mapping</p>
                          <div className="w-48 h-1 bg-ink/10 rounded-full mt-2 overflow-hidden">
                            <motion.div 
                              className="h-full bg-ink"
                              initial={{ width: 0 }}
                              animate={{ width: `${solvingProgress}%` }}
                            />
                          </div>
                        </div>
                      </div>
                    )}
                    
                    <div className="w-full h-full grid grid-cols-3 gap-1 p-1">
                      {images.length === 0 ? (
                        <div className="col-span-3 flex flex-col items-center justify-center opacity-10 space-y-4">
                          <Grid className="w-24 h-24" />
                          <p className="font-mono text-[10px] uppercase tracking-[0.4em]">Awaiting Input</p>
                        </div>
                      ) : (
                        images.map((img, i) => (
                          <div key={i} className="relative aspect-square bg-bg overflow-hidden group/img">
                            <img src={img} alt={`Captcha ${i}`} className="w-full h-full object-cover grayscale-[0.5] group-hover/img:grayscale-0 transition-all duration-500" />
                            <div className="absolute top-2 left-2 bg-ink/80 backdrop-blur-md text-bg text-[8px] px-1.5 py-0.5 font-mono rounded border border-white/10">
                              {i.toString().padStart(2, '0')}
                            </div>
                            
                            <AnimatePresence>
                              {result?.indices.includes(i) && (
                                <motion.div 
                                  initial={{ opacity: 0, scale: 1.2 }}
                                  animate={{ opacity: 1, scale: 1 }}
                                  className="absolute inset-0 bg-accent/20 border-4 border-accent flex items-center justify-center backdrop-blur-[2px]"
                                >
                                  <div className="bg-accent text-white p-2 rounded-full shadow-lg glow-emerald">
                                    <CheckCircle2 className="w-8 h-8" />
                                  </div>
                                </motion.div>
                              )}
                            </AnimatePresence>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </div>

                <AnimatePresence>
                  {result && (
                    <motion.div 
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="tech-card p-6 rounded-2xl space-y-6"
                    >
                      <div className="flex items-center justify-between">
                        <h3 className="tech-label">04. Neural Reasoning</h3>
                        <button 
                          onClick={() => copyToClipboard(JSON.stringify(result, null, 2))}
                          className="flex items-center gap-2 text-[9px] font-mono uppercase tracking-widest hover:text-accent transition-colors group"
                        >
                          {copied ? <CheckCircle2 className="w-3 h-3" /> : <Copy className="w-3 h-3 group-hover:scale-110 transition-transform" />}
                          {copied ? 'Copied' : 'Export JSON'}
                        </button>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-4">
                          <div className="flex items-start gap-4">
                            <div className="bg-ink text-bg p-2 rounded-lg">
                              <Cpu className="w-4 h-4" />
                            </div>
                            <div className="space-y-1">
                              <p className="text-[8px] font-mono uppercase tracking-widest opacity-40">Analysis Summary</p>
                              <p className="text-xs font-mono leading-relaxed opacity-80">{result.explanation}</p>
                            </div>
                          </div>
                        </div>

                        {result.puzzleData && (
                          <div className="bg-ink/5 p-4 rounded-xl space-y-4 tech-border">
                            <div className="grid grid-cols-2 gap-4">
                              <div className="space-y-1">
                                <p className="text-[8px] font-mono uppercase tracking-widest opacity-40">Target X/Y</p>
                                <div className="flex items-center justify-between bg-bg p-2 rounded-lg tech-border">
                                  <code className="text-[10px] font-mono font-bold">{result.puzzleData.targetX.toFixed(3)}, {result.puzzleData.targetY.toFixed(3)}</code>
                                  <button onClick={() => copyToClipboard(`${result.puzzleData?.targetX}, ${result.puzzleData?.targetY}`)} className="opacity-30 hover:opacity-100 transition-opacity">
                                    <Copy className="w-3 h-3" />
                                  </button>
                                </div>
                              </div>
                              <div className="space-y-1">
                                <p className="text-[8px] font-mono uppercase tracking-widest opacity-40">Interaction</p>
                                <div className="p-2 bg-bg rounded-lg tech-border text-[10px] font-mono font-bold uppercase tracking-widest text-accent">
                                  {result.puzzleData.isCheckbox ? 'Checkbox' : (result.puzzleData.sourceX !== undefined ? 'Drag' : 'Click')}
                                </div>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </section>
            </div>
          )}

          {activeTab === 'browser' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              <section className="lg:col-span-8 space-y-6">
                <div className="tech-card rounded-2xl overflow-hidden bg-white shadow-2xl">
                  {/* Browser Chrome */}
                  <div className="bg-ink/5 p-3 flex items-center gap-4 border-b border-ink/5">
                    <div className="flex gap-1.5">
                      <div className="w-3 h-3 rounded-full bg-red-400" />
                      <div className="w-3 h-3 rounded-full bg-amber-400" />
                      <div className="w-3 h-3 rounded-full bg-accent" />
                    </div>
                    <div className="flex-1 flex gap-2">
                      <div className="flex bg-bg rounded-lg tech-border px-3 py-1.5 flex-1 items-center gap-3 group focus-within:ring-2 focus-within:ring-accent/20 transition-all">
                        <Globe className="w-3.5 h-3.5 opacity-30 group-focus-within:text-accent transition-colors" />
                        <input 
                          type="text" 
                          value={browserUrl}
                          onChange={(e) => setBrowserUrl(e.target.value)}
                          className="bg-transparent text-[11px] font-mono w-full focus:outline-none"
                          placeholder="https://target-verification.com"
                        />
                      </div>
                      <button 
                        onClick={handleBrowserGoto}
                        disabled={browserLoading}
                        className="bg-ink text-bg px-4 py-1.5 rounded-lg text-[10px] font-mono uppercase tracking-widest hover:bg-ink/90 transition-all disabled:opacity-30"
                      >
                        {browserLoading ? <Loader2 className="w-3 h-3 animate-spin" /> : 'Go'}
                      </button>
                    </div>
                    <button 
                      onClick={() => handleBrowserAction('refresh', 0, 0)}
                      className="p-2 hover:bg-ink/5 rounded-lg transition-colors opacity-40 hover:opacity-100"
                    >
                      <RefreshCw className="w-4 h-4" />
                    </button>
                  </div>

                  <div 
                    className="relative bg-stone-100 overflow-hidden group"
                    style={{ aspectRatio: '16/10' }}
                  >
                    {browserScreenshot ? (
                      <div className="relative w-full h-full cursor-crosshair" onClick={(e) => {
                        if (pendingAction) return;
                        const rect = e.currentTarget.getBoundingClientRect();
                        const x = (e.clientX - rect.left) / rect.width;
                        const y = (e.clientY - rect.top) / rect.height;
                        handleBrowserAction('click', x, y);
                      }}>
                        <img 
                          src={browserScreenshot} 
                          alt="Browser View" 
                          className="w-full h-full object-contain"
                        />
                        
                        <AnimatePresence>
                          {pendingAction && (
                            <motion.div 
                              initial={{ opacity: 0, y: 20, x: '-50%' }}
                              animate={{ opacity: 1, y: 0, x: '-50%' }}
                              exit={{ opacity: 0, y: 20, x: '-50%' }}
                              className="absolute bottom-8 left-1/2 bg-white/90 backdrop-blur-md border border-ink/10 p-4 rounded-2xl shadow-2xl flex items-center gap-6 z-30 min-w-[450px]"
                            >
                              <div className="flex items-center gap-4">
                                <div className={`w-12 h-12 flex items-center justify-center rounded-xl shadow-inner ${
                                  pendingAction.type === 'drag' ? 'bg-warning/10 text-warning' : 
                                  pendingAction.type === 'type' ? 'bg-purple-100 text-purple-600' : 
                                  'bg-accent/10 text-accent'
                                }`}>
                                  {pendingAction.type === 'drag' ? <Move className="w-6 h-6" /> : 
                                   pendingAction.type === 'type' ? <FileText className="w-6 h-6" /> : 
                                   <Search className="w-6 h-6" />}
                                </div>
                                <div className="space-y-0.5">
                                  <span className="tech-label">Action Validation</span>
                                  <span className="block text-xs font-bold uppercase tracking-tight">
                                    {pendingAction.type === 'drag' ? 'Execute Puzzle Bypass' : 
                                     pendingAction.type === 'type' ? `Inject: "${pendingAction.text}"` : 
                                     'Execute Interaction'}
                                  </span>
                                </div>
                              </div>
                              
                              <div className="flex-1 h-10 w-px bg-ink/5" />
                              
                              <div className="flex items-center gap-3">
                                <button 
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    executePendingAction();
                                  }}
                                  disabled={browserLoading}
                                  className="bg-accent text-white px-6 py-3 rounded-xl text-[10px] font-bold uppercase tracking-[0.2em] hover:bg-accent/90 transition-all shadow-lg glow-emerald flex items-center gap-2"
                                >
                                  {browserLoading ? <Loader2 className="w-3 h-3 animate-spin" /> : <CheckCircle2 className="w-3 h-3" />}
                                  Confirm
                                </button>
                                <button 
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setPendingAction(null);
                                  }}
                                  className="text-[10px] font-bold uppercase tracking-widest hover:bg-ink/5 px-4 py-3 rounded-xl transition-colors"
                                >
                                  Cancel
                                </button>
                              </div>
                            </motion.div>
                          )}
                        </AnimatePresence>

                        {/* Visual Markers */}
                        {pendingAction && (
                          <>
                            {pendingAction.type === 'drag' && pendingAction.targetX !== undefined && (
                              <>
                                <motion.div 
                                  initial={{ scale: 0 }}
                                  animate={{ scale: 1 }}
                                  style={{ left: `${pendingAction.x * 100}%`, top: `${pendingAction.y * 100}%` }}
                                  className="absolute -translate-x-1/2 -translate-y-1/2 w-12 h-12 border-2 border-warning rounded-xl bg-warning/10 flex items-center justify-center glow-amber"
                                >
                                  <div className="tech-label absolute -top-6 whitespace-nowrap bg-white px-2 rounded shadow-sm">Source</div>
                                  <div className="w-2 h-2 bg-warning rounded-full" />
                                </motion.div>
                                
                                <motion.div 
                                  initial={{ scale: 0 }}
                                  animate={{ scale: 1 }}
                                  style={{ left: `${pendingAction.targetX * 100}%`, top: `${pendingAction.targetY * 100}%` }}
                                  className="absolute -translate-x-1/2 -translate-y-1/2 w-14 h-14 border-2 border-dashed border-accent rounded-full bg-accent/10 flex items-center justify-center glow-emerald"
                                >
                                  <div className="tech-label absolute -top-6 whitespace-nowrap bg-white px-2 rounded shadow-sm">Target</div>
                                  <div className="w-2.5 h-2.5 bg-accent rounded-full animate-ping" />
                                </motion.div>

                                <svg className="absolute inset-0 w-full h-full pointer-events-none">
                                  <motion.line
                                    initial={{ pathLength: 0, opacity: 0 }}
                                    animate={{ pathLength: 1, opacity: 0.4 }}
                                    x1={`${pendingAction.x * 100}%`}
                                    y1={`${pendingAction.y * 100}%`}
                                    x2={`${pendingAction.targetX * 100}%`}
                                    y2={`${pendingAction.targetY * 100}%`}
                                    stroke="#10B981"
                                    strokeWidth="2"
                                    strokeDasharray="6 4"
                                  />
                                </svg>
                              </>
                            )}

                            {(pendingAction.type === 'click' || pendingAction.type === 'type') && (
                              <motion.div 
                                initial={{ scale: 0 }}
                                animate={{ scale: 1 }}
                                style={{ left: `${pendingAction.x * 100}%`, top: `${pendingAction.y * 100}%` }}
                                className={`absolute -translate-x-1/2 -translate-y-1/2 w-14 h-14 border-2 border-dashed rounded-full flex items-center justify-center ${
                                  pendingAction.type === 'type' ? 'border-purple-500 bg-purple-500/10' : 'border-blue-500 bg-blue-500/10'
                                }`}
                              >
                                <div className={`tech-label absolute -top-6 whitespace-nowrap bg-white px-2 rounded shadow-sm ${
                                  pendingAction.type === 'type' ? 'text-purple-700' : 'text-blue-700'
                                }`}>
                                  {pendingAction.type === 'type' ? 'Input' : 'Interaction'}
                                </div>
                                <div className={`w-3 h-3 rounded-full animate-pulse ${
                                  pendingAction.type === 'type' ? 'bg-purple-500' : 'bg-blue-500'
                                }`} />
                              </motion.div>
                            )}
                          </>
                        )}
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center h-full text-ink/20 space-y-4">
                        <Globe className="w-16 h-16 opacity-10" />
                        <p className="tech-label">Awaiting Session Initiation</p>
                      </div>
                    )}
                    {browserLoading && (
                      <div className="absolute inset-0 bg-bg/60 backdrop-blur-sm flex flex-col items-center justify-center gap-4">
                        <Loader2 className="w-10 h-10 animate-spin text-accent" />
                        <p className="tech-label animate-pulse">Synchronizing State...</p>
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex gap-4">
                  <button 
                    onClick={handleSolveOnPage}
                    disabled={!browserScreenshot || loading}
                    className="flex-1 bg-accent text-white py-5 rounded-2xl text-[11px] font-bold uppercase tracking-[0.3em] hover:bg-accent/90 transition-all flex items-center justify-center gap-4 shadow-xl glow-emerald disabled:opacity-30"
                  >
                    {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Cpu className="w-5 h-5" />}
                    Solve Challenge on Page
                  </button>
                  <button 
                    onClick={() => handleBrowserAction('refresh', 0, 0)}
                    className="tech-card px-8 py-5 rounded-2xl hover:bg-ink/5 transition-all"
                  >
                    <RefreshCw className="w-5 h-5 opacity-40" />
                  </button>
                </div>
              </section>

              <section className="lg:col-span-4 space-y-6">
                <div className="tech-card p-6 rounded-2xl space-y-6">
                  <h3 className="tech-label">Session Telemetry</h3>
                  <div className="space-y-4">
                    {[
                      { label: 'Fingerprint', value: 'VERIFIED_HUMAN', color: 'text-accent' },
                      { label: 'Risk Score', value: '0.02 (LOW)', color: 'text-accent' },
                      { label: 'Interaction', value: 'NATURAL_JITTER', color: 'text-ink' },
                      { label: 'Environment', value: 'CHROMIUM_120', color: 'text-ink' },
                      { label: 'Proxy Node', value: 'US-EAST-1', color: 'text-ink' }
                    ].map((item) => (
                      <div key={item.label} className="flex justify-between items-center border-b border-ink/5 pb-2">
                        <span className="tech-label opacity-30">{item.label}</span>
                        <span className={`tech-value ${item.color}`}>{item.value}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <AnimatePresence>
                  {result && (
                    <motion.div 
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      className="tech-card p-6 rounded-2xl space-y-4"
                    >
                      <div className="flex items-center gap-3">
                        <div className="bg-accent/10 p-2 rounded-lg text-accent">
                          <FileText className="w-4 h-4" />
                        </div>
                        <h3 className="tech-label">Analysis Output</h3>
                      </div>
                      <p className="text-xs font-mono leading-relaxed opacity-70">
                        {result.puzzleData ? (
                          <>
                            <span className="text-warning font-bold">[PUZZLE]</span> {result.puzzleData.reasoning}
                          </>
                        ) : result.explanation}
                      </p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </section>
            </div>
          )}

          {activeTab === 'infra' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              <section className="lg:col-span-8 space-y-6">
                <div className="tech-card rounded-2xl overflow-hidden">
                  <div className="p-4 border-b border-ink/5 bg-ink/5 flex justify-between items-center">
                    <div className="flex items-center gap-3">
                      <div className="bg-accent/10 p-2 rounded-lg text-accent">
                        <Shield className="w-4 h-4" />
                      </div>
                      <h3 className="tech-label">Proxy Infrastructure</h3>
                    </div>
                    <button 
                      onClick={handleAddProxy}
                      className="bg-ink text-bg px-4 py-1.5 rounded-lg text-[10px] font-mono uppercase tracking-widest hover:bg-ink/90 transition-all"
                    >
                      Add Proxy
                    </button>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-ink/5">
                          <th className="p-4 tech-label opacity-40">Server</th>
                          <th className="p-4 tech-label opacity-40">Status</th>
                          <th className="p-4 tech-label opacity-40">Latency</th>
                          <th className="p-4 tech-label opacity-40">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-ink/5">
                        {proxies.map((proxy, i) => (
                          <tr key={i} className={`hover:bg-ink/5 transition-colors group ${i === currentProxyIndex ? 'bg-accent/5' : ''}`}>
                            <td className="p-4 tech-value">
                              <div className="flex items-center gap-2">
                                {i === currentProxyIndex && <div className="w-2 h-2 bg-accent rounded-full glow-emerald" title="Current Active Proxy" />}
                                {proxy.server}
                              </div>
                            </td>
                            <td className="p-4">
                              <span className="flex items-center gap-2 tech-value text-accent">
                                <div className="w-1.5 h-1.5 bg-accent rounded-full animate-pulse" />
                                {proxy.status}
                              </span>
                            </td>
                            <td className="p-4 tech-value">{proxy.latency}</td>
                            <td className="p-4">
                              <div className="flex gap-4">
                                <button 
                                  onClick={handleRotateProxy}
                                  className="text-[10px] font-bold uppercase tracking-widest text-accent hover:underline"
                                >
                                  Rotate
                                </button>
                                <button 
                                  onClick={() => handleDeleteProxy(i)}
                                  className="text-[10px] font-bold uppercase tracking-widest text-red-500 hover:underline"
                                >
                                  Delete
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {[
                    { label: 'Session Persistence', value: 'Sticky (30m)', icon: <Clock className="w-4 h-4" /> },
                    { label: 'IP Diversity', value: 'Residential / ISP', icon: <Globe className="w-4 h-4" /> },
                    { label: 'Traffic Pattern', value: 'Low-Volume Burst', icon: <Activity className="w-4 h-4" /> }
                  ].map((item) => (
                    <div key={item.label} className="tech-card p-6 rounded-2xl space-y-3">
                      <div className="flex items-center gap-3">
                        <div className="bg-ink/5 p-2 rounded-lg opacity-40">{item.icon}</div>
                        <span className="tech-label opacity-40">{item.label}</span>
                      </div>
                      <div className="text-xl font-serif italic text-ink">{item.value}</div>
                    </div>
                  ))}
                </div>
              </section>

              <section className="lg:col-span-4 space-y-6">
                <div className="tech-card p-6 rounded-2xl space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Shield className="w-4 h-4 text-accent" />
                      <h3 className="tech-label">Reputation & Trust</h3>
                    </div>
                    <div className="px-2 py-0.5 rounded bg-accent/10 border border-accent/20">
                      <span className="text-[10px] font-bold text-accent uppercase tracking-widest">High Trust</span>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="p-4 rounded-xl bg-ink/5 border border-ink/5">
                      <div className="text-[10px] tech-label opacity-40 mb-1">Trust Score</div>
                      <div className="text-3xl font-mono font-bold text-ink">{reputation.trustScore}%</div>
                      <div className="w-full h-1 bg-ink/10 rounded-full mt-2 overflow-hidden">
                        <div className="h-full bg-accent" style={{ width: `${reputation.trustScore}%` }} />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-3 rounded-xl bg-ink/5 border border-ink/5">
                        <div className="text-[10px] tech-label opacity-40 mb-1">IP Quality</div>
                        <div className="text-xs font-bold text-accent">{reputation.ipQuality}</div>
                      </div>
                      <div className="p-3 rounded-xl bg-ink/5 border border-ink/5">
                        <div className="text-[10px] tech-label opacity-40 mb-1">Session Age</div>
                        <div className="text-xs font-bold text-ink">{reputation.sessionAge}</div>
                      </div>
                    </div>

                    <div className="p-3 rounded-xl bg-accent/5 border border-accent/20 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Globe className="w-3 h-3 text-accent" />
                        <span className="text-[10px] font-bold text-ink">Network Consistency</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <div className="w-1.5 h-1.5 rounded-full bg-accent animate-pulse" />
                        <span className="text-[8px] font-bold text-accent uppercase">Synced</span>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="text-[10px] tech-label opacity-40 uppercase tracking-widest">Recent History</div>
                      {reputation.history.map((item, idx) => (
                        <div key={idx} className="flex items-center justify-between p-2 rounded border border-ink/5 bg-white/50">
                          <div className="flex items-center gap-2">
                            <CheckCircle2 className="w-3 h-3 text-accent" />
                            <div>
                              <div className="text-[10px] font-bold text-ink">{item.event}</div>
                              <div className="text-[8px] opacity-40">{item.time}</div>
                            </div>
                          </div>
                          <div className="text-[8px] font-bold text-accent uppercase">{item.status}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="tech-card p-6 rounded-2xl space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Download className="w-4 h-4 text-accent" />
                      <h3 className="tech-label">Session Export</h3>
                    </div>
                  </div>
                  <div className="p-4 rounded-xl bg-ink/5 border border-ink/5 space-y-4">
                    <p className="text-[10px] opacity-60 leading-relaxed">
                      Export the current browser session (cookies, localStorage, userAgent) to synchronize with your external bot or script. This ensures token origin and network consistency.
                    </p>
                    <button 
                      onClick={async () => {
                        try {
                          const res = await fetch('/api/browser/state');
                          const data = await res.json();
                          const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
                          const url = URL.createObjectURL(blob);
                          const a = document.createElement('a');
                          a.href = url;
                          a.download = `session_${new Date().getTime()}.json`;
                          a.click();
                        } catch (e) {
                          console.error("Export failed", e);
                        }
                      }}
                      className="w-full py-2 rounded-lg bg-ink text-white text-[10px] font-bold uppercase tracking-widest hover:bg-accent transition-colors flex items-center justify-center gap-2"
                    >
                      <Download className="w-3 h-3" />
                      Download Session Bundle
                    </button>
                  </div>
                </div>

                <div className="tech-card p-6 rounded-2xl space-y-6">
                  <h3 className="tech-label">Network Topology</h3>
                  <div className="aspect-square relative flex items-center justify-center">
                    <div className="absolute inset-0 border border-ink/5 rounded-full animate-[spin_20s_linear_infinite]" />
                    <div className="absolute inset-4 border border-ink/5 rounded-full animate-[spin_15s_linear_infinite_reverse]" />
                    <div className="absolute inset-8 border border-ink/5 rounded-full animate-[spin_10s_linear_infinite]" />
                    <div className="relative z-10 bg-white p-4 rounded-2xl shadow-xl border border-ink/10">
                      <Server className="w-8 h-8 text-accent" />
                    </div>
                    <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-accent w-2 h-2 rounded-full glow-emerald" />
                    <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-1/2 bg-warning w-2 h-2 rounded-full glow-amber" />
                  </div>
                  <div className="space-y-4 pt-4">
                    <div className="flex justify-between items-center">
                      <span className="tech-label opacity-30">Active Nodes</span>
                      <span className="tech-value">12 / 12</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="tech-label opacity-30">Uptime</span>
                      <span className="tech-value text-accent">99.99%</span>
                    </div>
                  </div>
                </div>
              </section>
            </div>
          )}

          {/* Realism Engine Tab */}
          {activeTab === 'realism' && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="grid grid-cols-1 lg:grid-cols-2 gap-8"
            >
              {/* Fingerprint Management */}
              <div className="space-y-6">
                <div className="tech-card p-6 space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-accent/10 rounded-lg text-accent">
                        <Fingerprint className="w-5 h-5" />
                      </div>
                      <h2 className="text-sm font-bold uppercase tracking-wider">Environment Fingerprinting</h2>
                    </div>
                    <button 
                      onClick={() => {
                        const uas = [
                          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
                          'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
                          'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
                        ];
                        const res = ['1920x1080', '2560x1440', '1440x900', '1366x768'];
                        setFingerprint({
                          ...fingerprint,
                          userAgent: uas[Math.floor(Math.random() * uas.length)],
                          resolution: res[Math.floor(Math.random() * res.length)]
                        });
                      } }
                      className="text-[10px] font-bold uppercase tracking-widest text-accent hover:underline"
                    >
                      Rotate Identity
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <span className="tech-label">User Agent</span>
                      <div className="tech-value truncate text-[10px]">{fingerprint.userAgent}</div>
                    </div>
                    <div className="space-y-1">
                      <span className="tech-label">Resolution</span>
                      <div className="tech-value">{fingerprint.resolution}</div>
                    </div>
                    <div className="space-y-1">
                      <span className="tech-label">WebGL Renderer</span>
                      <div className="tech-value">{fingerprint.webgl}</div>
                    </div>
                    <div className="space-y-1">
                      <span className="tech-label">Locale / Timezone</span>
                      <div className="tech-value">{fingerprint.language} / {fingerprint.timezone}</div>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-ink/5 space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <span className="text-xs font-bold uppercase tracking-tight">Advanced Fingerprinting</span>
                        <p className="text-[10px] opacity-50">Canvas, WebGL, and Audio noise injection</p>
                      </div>
                      <div className="flex gap-2">
                        {[
                          { id: 'canvasProtection', label: 'C' },
                          { id: 'webglProtection', label: 'W' },
                          { id: 'audioProtection', label: 'A' }
                        ].map(p => (
                          <button
                            key={p.id}
                            onClick={() => setRealismSettings(prev => ({ ...prev, [p.id]: !prev[p.id as keyof typeof prev] }))}
                            className={`w-6 h-6 rounded flex items-center justify-center text-[10px] font-bold transition-all border ${realismSettings[p.id as keyof typeof realismSettings] ? 'bg-accent border-accent text-white' : 'bg-ink/5 border-ink/10 text-ink/40'}`}
                            title={p.id}
                          >
                            {p.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <span className="text-xs font-bold uppercase tracking-tight">Session Persistence</span>
                        <p className="text-[10px] opacity-50">Maintain cookies and local storage across runs</p>
                      </div>
                      <button 
                        onClick={() => setRealismSettings(prev => ({ ...prev, sessionPersistence: !prev.sessionPersistence }))}
                        className={`w-10 h-5 rounded-full transition-colors relative ${realismSettings.sessionPersistence ? 'bg-accent' : 'bg-ink/10'}`}
                      >
                        <div className={`absolute top-1 w-3 h-3 bg-white rounded-full transition-all ${realismSettings.sessionPersistence ? 'left-6' : 'left-1'}`} />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Network Simulation */}
                <div className="tech-card p-6 space-y-6">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-blue-500/10 rounded-lg text-blue-500">
                      <Wifi className="w-5 h-5" />
                    </div>
                    <h2 className="text-sm font-bold uppercase tracking-wider">Network Environment</h2>
                  </div>

                  <div className="space-y-6">
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="tech-label">Latency (ms)</span>
                        <span className="text-xs font-mono">{networkThrottling.latency}ms</span>
                      </div>
                      <input 
                        type="range" min="0" max="500" step="10"
                        value={networkThrottling.latency}
                        onChange={(e) => setNetworkThrottling(prev => ({ ...prev, latency: parseInt(e.target.value) }))}
                        className="w-full h-1 bg-ink/5 rounded-lg appearance-none cursor-pointer accent-accent"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <span className="tech-label">Packet Loss (%)</span>
                        <input 
                          type="number" min="0" max="100"
                          value={networkThrottling.packetLoss}
                          onChange={(e) => setNetworkThrottling(prev => ({ ...prev, packetLoss: parseInt(e.target.value) }))}
                          className="w-full bg-ink/5 border border-ink/10 rounded-lg p-2 text-xs font-mono focus:outline-none focus:border-accent"
                        />
                      </div>
                      <div className="space-y-2">
                        <span className="tech-label">Jitter (ms)</span>
                        <input 
                          type="number" min="0" max="500"
                          value={networkThrottling.jitter}
                          onChange={(e) => setNetworkThrottling(prev => ({ ...prev, jitter: parseInt(e.target.value) }))}
                          className="w-full bg-ink/5 border border-ink/10 rounded-lg p-2 text-xs font-mono focus:outline-none focus:border-accent"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <span className="tech-label">Download (kbps)</span>
                        <input 
                          type="number"
                          value={networkThrottling.downloadThroughput}
                          onChange={(e) => setNetworkThrottling(prev => ({ ...prev, downloadThroughput: parseInt(e.target.value) }))}
                          className="w-full bg-ink/5 border border-ink/10 rounded-lg p-2 text-xs font-mono focus:outline-none focus:border-accent"
                        />
                      </div>
                      <div className="space-y-2">
                        <span className="tech-label">Upload (kbps)</span>
                        <input 
                          type="number"
                          value={networkThrottling.uploadThroughput}
                          onChange={(e) => setNetworkThrottling(prev => ({ ...prev, uploadThroughput: parseInt(e.target.value) }))}
                          className="w-full bg-ink/5 border border-ink/10 rounded-lg p-2 text-xs font-mono focus:outline-none focus:border-accent"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Interaction Realism */}
              <div className="space-y-6">
                <div className="tech-card p-6 space-y-6">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-amber-500/10 rounded-lg text-amber-500">
                      <MousePointer2 className="w-5 h-5" />
                    </div>
                    <h2 className="text-sm font-bold uppercase tracking-wider">Behavioral Engine</h2>
                  </div>

                  <div className="space-y-6">
                    <div className="space-y-3">
                      <span className="tech-label">Behavioral Profile</span>
                      <div className="grid grid-cols-3 gap-2">
                        {(['casual', 'power', 'bot'] as const).map((p) => (
                          <button
                            key={p}
                            onClick={() => setBehavioralProfile(p)}
                            className={`p-3 rounded-xl border text-[10px] font-bold uppercase tracking-widest transition-all ${
                              behavioralProfile === p 
                                ? 'bg-ink text-bg border-ink shadow-lg' 
                                : 'bg-ink/5 border-ink/10 text-ink/40 hover:bg-ink/10'
                            }`}
                          >
                            {p}
                          </button>
                        ))}
                      </div>
                      <p className="text-[10px] opacity-50 italic">
                        {behavioralProfile === 'casual' && "Slow, hesitant movements with occasional typos and long pauses."}
                        {behavioralProfile === 'power' && "Efficient, fast movements with high accuracy and minimal hesitation."}
                        {behavioralProfile === 'bot' && "Instantaneous, direct movements with zero jitter and perfect accuracy."}
                      </p>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <span className="text-xs font-bold uppercase tracking-tight">Human-like Typing</span>
                        <p className="text-[10px] opacity-50">Variable character delays and random pauses</p>
                      </div>
                      <button 
                        onClick={() => setRealismSettings(prev => ({ ...prev, humanTyping: !prev.humanTyping }))}
                        className={`w-10 h-5 rounded-full transition-colors relative ${realismSettings.humanTyping ? 'bg-accent' : 'bg-ink/10'}`}
                      >
                        <div className={`absolute top-1 w-3 h-3 bg-white rounded-full transition-all ${realismSettings.humanTyping ? 'left-6' : 'left-1'}`} />
                      </button>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <span className="text-xs font-bold uppercase tracking-tight">Random Execution Delays</span>
                        <p className="text-[10px] opacity-50">Introduce variability between automation steps</p>
                      </div>
                      <button 
                        onClick={() => setRealismSettings(prev => ({ ...prev, randomDelays: !prev.randomDelays }))}
                        className={`w-10 h-5 rounded-full transition-colors relative ${realismSettings.randomDelays ? 'bg-accent' : 'bg-ink/10'}`}
                      >
                        <div className={`absolute top-1 w-3 h-3 bg-white rounded-full transition-all ${realismSettings.randomDelays ? 'left-6' : 'left-1'}`} />
                      </button>
                    </div>

                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="tech-label">Coordinate Jitter (px)</span>
                        <span className="text-xs font-mono">{realismSettings.jitter}px</span>
                      </div>
                      <input 
                        type="range" min="0" max="20" step="1"
                        value={realismSettings.jitter}
                        onChange={(e) => setRealismSettings(prev => ({ ...prev, jitter: parseInt(e.target.value) }))}
                        className="w-full h-1 bg-ink/5 rounded-lg appearance-none cursor-pointer accent-accent"
                      />
                      <p className="text-[10px] opacity-50 italic">Simulates natural inaccuracy in human clicking/dragging</p>
                    </div>
                  </div>
                </div>

                {/* Protocol Alignment */}
                <div className="tech-card p-6 space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-purple-500/10 rounded-lg text-purple-500">
                      <Zap className="w-5 h-5" />
                    </div>
                    <h2 className="text-sm font-bold uppercase tracking-wider">Protocol Integrity</h2>
                  </div>
                  
                  <div className="space-y-3">
                    <div className="flex items-center gap-2 text-[10px] text-emerald-600 font-bold uppercase">
                      <CheckCircle2 className="w-3 h-3" />
                      Navigator.webdriver Masking Active
                    </div>
                    <div className="flex items-center gap-2 text-[10px] text-emerald-600 font-bold uppercase">
                      <CheckCircle2 className="w-3 h-3" />
                      Client Hints (Sec-CH-UA) Aligned
                    </div>
                    <div className="flex items-center gap-2 text-[10px] text-emerald-600 font-bold uppercase">
                      <CheckCircle2 className="w-3 h-3" />
                      Hardware Concurrency Spoofing
                    </div>
                    <div className="flex items-center gap-2 text-[10px] text-emerald-600 font-bold uppercase">
                      <CheckCircle2 className="w-3 h-3" />
                      Canvas/Audio Fingerprint Protection
                    </div>
                  </div>
                  
                  <p className="text-[10px] opacity-50 leading-relaxed">
                    These low-level protocol alignments ensure the automated browser behaves identically to a standard installation at the networking and JavaScript runtime layers.
                  </p>
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'human' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              <section className="lg:col-span-8 space-y-6">
                <div className="tech-card rounded-2xl overflow-hidden">
                  <div className="p-4 border-b border-ink/5 bg-ink/5 flex justify-between items-center">
                    <div className="flex items-center gap-3">
                      <div className="bg-warning/10 p-2 rounded-lg text-warning">
                        <Users className="w-4 h-4" />
                      </div>
                      <h3 className="tech-label">Active Challenge Queue</h3>
                    </div>
                    <div className="flex gap-2">
                      <button className="tech-card px-4 py-1.5 rounded-lg text-[10px] font-mono uppercase tracking-widest hover:bg-ink/5 transition-all">
                        Pause Queue
                      </button>
                      <button className="bg-ink text-bg px-4 py-1.5 rounded-lg text-[10px] font-mono uppercase tracking-widest hover:bg-ink/90 transition-all">
                        Manual Solve
                      </button>
                    </div>
                  </div>
                  <div className="divide-y divide-ink/5">
                    {humanQueue.length > 0 ? humanQueue.map((task, i) => (
                      <div key={i} className="p-6 flex justify-between items-center hover:bg-ink/5 transition-colors group">
                        <div className="flex items-center gap-6">
                          <div className="w-12 h-12 bg-ink text-bg flex items-center justify-center rounded-xl font-mono text-xs shadow-lg">
                            {task.id.split('-')[1]}
                          </div>
                          <div className="space-y-1">
                            <div className="text-sm font-bold uppercase tracking-tight text-ink">{task.type}</div>
                            <div className="text-[10px] font-mono opacity-40">Received: {task.timestamp}</div>
                          </div>
                        </div>
                        <div className="flex items-center gap-8">
                          <span className={`text-[10px] font-bold uppercase px-3 py-1 rounded-full border ${
                            task.status === 'Pending' 
                              ? 'border-warning/30 text-warning bg-warning/5 glow-amber' 
                              : 'border-accent/30 text-accent bg-accent/5 glow-emerald'
                          }`}>
                            {task.status}
                          </span>
                          <button className="text-[10px] font-bold uppercase tracking-widest text-ink hover:underline flex items-center gap-2">
                            Inspect <ChevronRight className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    )) : (
                      <div className="p-20 flex flex-col items-center justify-center gap-4 opacity-20">
                        <Inbox className="w-12 h-12" />
                        <p className="tech-label">Queue Empty</p>
                      </div>
                    )}
                  </div>
                </div>

                <div className="p-12 border-2 border-dashed border-ink/5 rounded-3xl flex flex-col items-center justify-center gap-4 opacity-40">
                  <Activity className="w-8 h-8 animate-pulse" />
                  <p className="tech-label text-center">Monitoring for escalation triggers...</p>
                </div>
              </section>

              <section className="lg:col-span-4 space-y-6">
                <div className="tech-card p-6 rounded-2xl space-y-6">
                  <h3 className="tech-label">Queue Analytics</h3>
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <div className="flex justify-between tech-label opacity-40">
                        <span>Success Rate</span>
                        <span>98.2%</span>
                      </div>
                      <div className="h-1.5 bg-ink/5 rounded-full overflow-hidden">
                        <div className="h-full bg-accent w-[98.2%] rounded-full" />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between tech-label opacity-40">
                        <span>Avg. Solve Time</span>
                        <span>14.2s</span>
                      </div>
                      <div className="h-1.5 bg-ink/5 rounded-full overflow-hidden">
                        <div className="h-full bg-warning w-[65%] rounded-full" />
                      </div>
                    </div>
                  </div>
                </div>
              </section>
            </div>
          )}
        </div>
      </main>

      {/* Footer */}
      <footer className="mt-20 border-t border-ink/5 p-12 text-center">
        <div className="max-w-7xl mx-auto flex flex-col items-center gap-6">
          <div className="flex gap-8 opacity-30">
            {['Neural Engine', 'Vision Core', 'Proxy Mesh', 'Bypass Logic'].map((item) => (
              <span key={item} className="text-[10px] font-mono uppercase tracking-[0.2em]">{item}</span>
            ))}
          </div>
          <p className="text-[10px] font-mono uppercase tracking-[0.4em] opacity-20">
            &copy; 2026 AI SOLVER SYSTEMS &bull; ADVANCED NEURAL PROCESSING &bull; V1.0.4
          </p>
        </div>
      </footer>
    </div>
  );
}
