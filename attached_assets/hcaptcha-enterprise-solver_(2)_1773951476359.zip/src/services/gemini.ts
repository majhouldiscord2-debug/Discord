import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export interface ImageAnalysis {
  isMatch: boolean;
  confidence: number;
  reasoning: string;
}

export interface CaptchaResult {
  indices: number[];
  explanation: string;
  analysis?: ImageAnalysis[];
  puzzleData?: {
    selectedPieceIndex: number;
    sourceX?: number;
    sourceY?: number;
    targetX: number;
    targetY: number;
    text?: string;
    isCheckbox?: boolean;
    reasoning: string;
  };
}

export async function detectPrompt(
  images: string[],
  turbo: boolean = false
): Promise<string> {
  const model = "gemini-3-flash-preview";
  
  const imageParts = images.map((data) => ({
    inlineData: {
      data: data.split(",")[1],
      mimeType: "image/png",
    },
  }));

  const response = await ai.models.generateContent({
    model,
    contents: [
      {
        parts: [
          ...imageParts,
          { text: "Analyze these images. They represent a CAPTCHA or bot verification challenge. Identify the specific instruction or question the user needs to solve (e.g., 'Select all squares with traffic lights', 'Click on the object that is different', 'Type the characters you see', 'Please drag the correct piece to fill the empty space'). Extract and return ONLY the text of this instruction. Be precise. If multiple instructions are present, return the main one. If no instruction is found, return an empty string." }
        ],
      },
    ],
    config: {
      thinkingConfig: turbo ? { thinkingLevel: "LOW" as any } : undefined
    }
  });

  return response.text?.trim().replace(/^["']|["']$/g, "") || "";
}

export async function solvePuzzleChallenge(
  prompt: string,
  images: string[],
  turbo: boolean = false
): Promise<CaptchaResult> {
  const model = "gemini-3-flash-preview";
  
  const imageParts = images.map((data) => ({
    inlineData: {
      data: data.split(",")[1],
      mimeType: "image/png",
    },
  }));

  const systemInstruction = `
    You are a specialized human-like AI agent solving verification challenges within a live browser environment.
    
    Interaction Modes:
    1. Grid-based: Identify squares matching a prompt.
    2. Puzzle-based: Identify a piece (sourceX, sourceY) and its destination (targetX, targetY).
    3. Full-Page Interaction: Identify a specific interactive element (checkbox, button, slider handle, text field) and its center coordinates (targetX, targetY).
    
    Execution Logic:
    - For "I'm not a robot" checkboxes: Identify the exact center of the checkbox square. Provide center coordinates in 'targetX' and 'targetY'. Set 'isCheckbox' to true.
    - For slider puzzles: Provide slider handle in 'sourceX/Y' and destination in 'targetX/Y'.
    - For text fields: Provide field center in 'targetX/Y' and the text to enter in 'text'.
    - For grid challenges: Return the indices of matching squares.
    
    Precision Requirements:
    - Coordinates MUST be normalized (0.0 to 1.0) relative to the provided image dimensions.
    - Be extremely precise.
    
    Return JSON:
    {
      "explanation": "Human-like reasoning of what you see",
      "puzzleData": {
        "sourceX": number, // Optional: Start of drag
        "sourceY": number, // Optional: Start of drag
        "targetX": number, // Click point, end of drag, or text field center
        "targetY": number, // Click point, end of drag, or text field center
        "text": "string", // Optional: Text to type if target is a field
        "isCheckbox": boolean, // Optional: True if it's a checkbox click
        "reasoning": "Detailed geometric reasoning"
      },
      "indices": [number]
    }
  `;

  const response = await ai.models.generateContent({
    model,
    contents: [
      {
        parts: [
          ...imageParts,
          { text: `Challenge Prompt: ${prompt}\n\nAnalyze the images and solve the puzzle. Identify the correct piece and its target location.` }
        ],
      },
    ],
    config: {
      systemInstruction,
      responseMimeType: "application/json",
      thinkingConfig: turbo ? { thinkingLevel: "LOW" as any } : undefined
    },
  });

  try {
    const result = JSON.parse(response.text || "{}");
    return {
      indices: [],
      explanation: result.explanation || "Puzzle analyzed.",
      puzzleData: result.puzzleData
    };
  } catch (e) {
    console.error("Failed to parse Puzzle response", e);
    return { indices: [], explanation: "Error solving puzzle." };
  }
}

export async function solveCaptcha(
  prompt: string,
  images: string[], // base64 strings
  turbo: boolean = false
): Promise<CaptchaResult> {
  // Check if it's an interactive or puzzle challenge
  const isInteractive = prompt.toLowerCase().includes('drag') || 
                        prompt.toLowerCase().includes('piece') || 
                        prompt.toLowerCase().includes('fill') ||
                        prompt.toLowerCase().includes('empty space') ||
                        prompt.toLowerCase().includes('robot') ||
                        prompt.toLowerCase().includes('verify') ||
                        prompt.toLowerCase().includes('checkbox') ||
                        prompt.toLowerCase().includes('click');

  if (isInteractive) {
    return solvePuzzleChallenge(prompt, images, turbo);
  }

  const model = "gemini-3-flash-preview";

  const imageParts = images.map((data, index) => ({
    inlineData: {
      data: data.split(",")[1], // remove data:image/png;base64,
      mimeType: "image/png",
    },
  }));

  const systemInstruction = `
    You are a specialized human-like AI agent solving verification challenges.
    
    Types of challenges you can solve:
    1. Grid-based: Identify squares that match a prompt.
    2. Puzzle-based: Identify which piece fits into a hole and its target (x, y) coordinates.
    3. Full-Page Interaction: Identify a specific element (button, checkbox, slider) and its (x, y) coordinates to interact with.
    
    Guidelines:
    1. Precision: Coordinates (targetX, targetY) must be normalized (0.0 to 1.0) relative to the image.
    2. Context: If you see a "Verify you are human" checkbox, provide its center coordinates.
    
    Return the result in JSON format:
    {
      "explanation": "Summary of your plan",
      "puzzleData": {
        "selectedPieceIndex": number,
        "sourceX": number,
        "sourceY": number,
        "targetX": number,
        "targetY": number,
        "reasoning": "Why this point?"
      },
      "indices": [number],
      "analysis": [
        { "isMatch": boolean, "confidence": number, "reasoning": "string" }
      ]
    }
  `;

  const response = await ai.models.generateContent({
    model,
    contents: [
      {
        parts: [
          { text: `Challenge Instruction: "${prompt}"` },
          ...imageParts.map((part, i) => ([
            { text: `Square ${i}:` },
            part
          ])).flat(),
          { text: "Analyze each square and determine if it matches the instruction. Provide your reasoning as a human would." }
        ],
      },
    ],
    config: {
      systemInstruction,
      responseMimeType: "application/json",
      thinkingConfig: turbo ? { thinkingLevel: "LOW" as any } : undefined
    },
  });

  try {
    const result = JSON.parse(response.text || "{}");
    return {
      indices: result.indices || [],
      explanation: result.explanation || "No explanation provided.",
      analysis: result.analysis || [],
      puzzleData: result.puzzleData
    };
  } catch (e) {
    console.error("Failed to parse Gemini response", e);
    return { indices: [], explanation: "Error parsing AI response.", analysis: [] };
  }
}
